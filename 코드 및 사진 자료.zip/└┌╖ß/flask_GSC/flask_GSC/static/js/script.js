document.addEventListener('DOMContentLoaded', function() {
    var btn = document.getElementById('submit');
    var error = document.getElementById('error');
    btn.addEventListener('mouseenter', function() {
        this.classList.add('hover');
    });
    btn.addEventListener('mouseleave', function() {
        this.classList.remove('hover');
    });
    var enter = document.getElementById('password');
    enter.addEventListener('keypress', function(event) {
	if (event.key === 'Enter') {
            event.preventDefault();
            btn.click();
        }
    });
    btn.addEventListener('click', function(event) {
        event.preventDefault();
        var id_ = document.getElementById('id')
        var id = id_.value;
        var password = enter.value;
	if (!id) {
            alert('[사용자 아이디] 반드시 입력(선택)하셔야 합니다.');
            return;
        }
	else if (!password) {
            alert('[비밀번호] 반드시 입력(선택)하셔야 합니다.');
            return;
	}
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/login', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                var response = JSON.parse(xhr.responseText);
                if (response.message === 'success') {
		    window.location.href = "https://cyber.gachon.ac.kr"
                } 
                else {
                    error.style.display = 'block';
                    id_.value = '';
                    enter.value = '';
                }
            }
        };
        var data = JSON.stringify({'id': id, 'password': password});
        xhr.send(data);
    });
});
