document.getElementById('submit').addEventListener('mouseenter', function() {
    this.classList.add('hover');
});

document.getElementById('submit').addEventListener('mouseleave', function() {
    this.classList.remove('hover');
});
